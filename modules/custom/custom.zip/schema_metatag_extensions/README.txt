INSTALL
==========

1. Extract module into /modules folder.
2. Enable "Schema.org Metatag Extensions".


CREDITS
=========

Module was developed by Ruslan Piskarev (https://www.drupal.org/u/ruslan-p).
